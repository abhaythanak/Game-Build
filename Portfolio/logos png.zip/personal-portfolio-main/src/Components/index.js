
import NavBar from "./NavBar"
import Home from "./Home"
import Portfolio from "./Portfolio"


export {
    NavBar,
    Home,
    Portfolio
}